from skylark_ai.clients import Service
from skylark_ai.face_mask_stream import FaceMaskStreamClient
import time

# user will add authorization token here
token = "fac2f104431d289d6a3e3d6711f0d1535a6af3d9"

# user will send fps of incoming stream, size of batch that will be formed while processing ,
# the rate at which sampling is done, and the token
c = FaceMaskStreamClient(
	fps=15,
	batch_size=1,
	sampling_rate=2,
	token=token
)

# user can continue to perform any further tasks as per need
while True:
	print("wow")
	time.sleep(1)
