HOST = "api.skylarklabs.ai"
HTTPS_PROTOCOL = "https://"
WEBSOCKET_AUTH_API = "%s%s/%s" % (HTTPS_PROTOCOL, HOST, "web-socket-token/")
