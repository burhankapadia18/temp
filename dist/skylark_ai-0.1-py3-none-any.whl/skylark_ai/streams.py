import cv2
import time
import asyncio
import math
import threading
from skylark_ai.clients import RealTimeClient


class StreamClient:
	def __init__(self, fps, batch_size, sampling_rate, service, token):
		self.fps = fps
		self.frames = []
		self.json = ""
		self.syncid = -1
		self.batch_size = batch_size
		self.sampling_rate = sampling_rate
		self.sample_length = int(fps / sampling_rate)
		self.delay_sec = 1 / self.fps
		self.vid = cv2.VideoCapture(0, cv2.CAP_DSHOW)
		self.service = service
		self.token = token
		self.client = RealTimeClient(service, self.on_receive, batch_size, self.on_network_status_change, token)
		self.response_jsons = []
		self.createTasks()

	def createTasks(self):
		# running these three tasks on a seperate thread so that the main thread does'nt gets blocked
		tasks = [
			asyncio.ensure_future(self.start_stream()),
			asyncio.ensure_future(self.client.receive_message()),
			asyncio.ensure_future(self.show_stream()),
		]
		threading.Thread(target=self.run_tasks, args=(asyncio.get_event_loop(), tasks)).start()

	async def on_network_status_change(self):
		# method to restart tasks stopped if some network issue occurs and websocket connection gets closed
		print("re-running tasks")
		await self.client.re_connect()
		await asyncio.sleep(1)

	def run_tasks(self, loop, tasks):
		# runs the tasks sent as a list here
		asyncio.set_event_loop(loop)
		loop.run_until_complete(asyncio.wait(tasks))

	async def show_stream(self):
		# on message receive from websocket, we parse json response and show stream using cv2
		while True:
			if len(self.response_jsons) == 0:
				# if no responses then keep waiting for some message to be received
				print("waiting")
				await asyncio.sleep(1)
				continue
			# take out one of the response from beginning and apply the result to the frames
			response = self.response_jsons.pop(0)
			# syncid is used to maintain between sent and received frames
			self.syncid = self.syncid + self.batch_size
			syncids = response["sync"]
			if self.syncid != syncids[-1]:
				# if syncid sent and received for a particular response is not same then acheive sync
				print("not in sync:")
				print(self.syncid)
				print(syncids[-1])
				if self.syncid > syncids[-1]:
					# discarding results
					while self.syncid != syncids[-1]:
						syncids = response["sync"]
						self.response_jsons.pop(0)
				else:
					# discarding frames
					while self.syncid != syncids[-1]:
						self.frames.pop()
						self.syncid = self.syncid + 1
				continue
			else:
				# when in sync move further
				try:
					for result in response['results']:
						for i in range(self.sample_length):
							frame = self.frames.pop(0)
							start = time.time()
							for face in result["faces"]:
								print(face)
								# fetching coordinates for each face
								coords = face["coordinates"]
								start_point = (coords["left"], coords["top"])
								end_point = (coords["right"], coords["bottom"])
								if face["has_mask"]:
									color = (0, 255, 0)
								else:
									color = (0, 0, 255)
								thickness = 1
								# creating face rectangles using cv2
								cv2.imshow('outputstream', cv2.rectangle(
									frame,
									start_point,
									end_point, color, thickness
								))
							# finding time taken in doing all above tasks and waiting
							time_spent = time.time() - start
							rem_time = max(self.delay_sec - time_spent, 0)
							await asyncio.sleep(rem_time)
				except Exception as e:
					print(e)

	def on_receive(self, json):
		try:
			# whenever a message is received we store them in a list
			if "results" in json and self.frames.__len__() > 0:
				self.response_jsons.append(json)

		except Exception as e:
			print(str(e))

	async def start_stream(self):
		# variable used to maintain the count of frames already sampled
		counter = 0
		while True:
			try:
				start = time.time()
				ret, frame = self.vid.read()
				# cv2.imshow('inputstream', frame)
				self.frames.append(frame)
				print(self.frames.__len__())
				# for every frames equal to sample_length picking one frame from the middle and sending for processing
				counter = (counter + 1) % self.sample_length
				if counter == 0:
					# print("len:")
					# print(self.frames.__len__())
					selected_frame = self.frames[-self.sample_length:][
						-int(math.floor(math.floor(self.sample_length / 2)))]
					if selected_frame is not None:
						byte_array = cv2.imencode('.jpg', selected_frame)[1].tostring()
						await self.client.start_stream(byte_array)
				time_spent = time.time() - start
				rem_time = max(self.delay_sec - time_spent, 0)
				await asyncio.sleep(rem_time)
				# if q is pressed we stop showing output stream
				if cv2.waitKey(1) & 0xFF == ord('q'):
					self.vid.release()
					cv2.destroyAllWindows()
					break
			except Exception as e:
				print(str(e))
