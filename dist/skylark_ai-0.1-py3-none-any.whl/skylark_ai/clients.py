import threading
import json
import time
from enum import Enum
from functools import reduce
import uuid
import os
import socket
import asyncio
import websockets

from skylark_ai.utils import get_websocket_auth_token, get_bytes_from_file
from skylark_ai.constants import HOST


class Service(Enum):
	FACE_MASK = 1,

	def get_uri(self):
		return service_uri_map.get(self, None)


service_uri_map = {
	Service.FACE_MASK: "face-mask/"
}


class RealTimeClient:
	protocol = "wss://"
	route = "ws/"

	def __init__(self, service, on_receive, batch_size, on_network_status_change,  token=None):
		self.service = service
		self.on_network_status_change = on_network_status_change
		self.url = self.protocol + HOST + "/" + self.route + service.get_uri()
		self.path = os.path.join(os.getcwd(), "media", "directory_streams", "test_stream")
		print(self.url)
		self.token = token
		self.syncid = 0
		self.websocket_token = get_websocket_auth_token(token)
		self.on_receive = on_receive
		print(self.websocket_token)
		self.url = self.url + "?authorization=%s" % self.websocket_token
		self.websocket = None
		loop = asyncio.get_event_loop()
		loop.run_until_complete(self._connect())
		loop.run_until_complete(self.set_batch_size(batch_size))

	async def start_stream(self, byte_array):
		while self.websocket is None:
			print("none")
			time.sleep(1)
			continue
		try:
			if byte_array is not None:
				# starting and sending frame one by one
				await self.start_frame(byte_array.__len__(), self.syncid)
				await self.send_frame(byte_array)
		except websockets.exceptions.ConnectionClosed:
			print("connection closed in start stream")
			print("re-establishing connection...")
			self.websocket = None
			await self.on_network_status_change()

		except socket.gaierror:
			await self.on_network_status_change()

	async def set_batch_size(self, batch_size):
		print("setting batch size")
		while self.websocket is None:
			# if connection is closed we wait for reconnection
			print("none")
			time.sleep(1)
			continue
		try:
			await self.websocket.send(json.dumps({
				"action": 'set_batch_size',
				"batchSize": batch_size
			}))
		except websockets.exceptions.ConnectionClosed:
			print("connection closed in setting batch size")
			print("re-establishing connection...")
			self.websocket = None
			await self.on_network_status_change()

	async def start_frame(self, byte_length, syncid):
		print("starting frame")
		self.syncid = self.syncid+1
		while self.websocket is None:
			time.sleep(1)
			print("none found")
			continue
		try:
			await self.websocket.send(json.dumps({
				"fileSize": byte_length,
				"syncId": syncid,
				"action": "start_frame"
			}))
		except websockets.exceptions.ConnectionClosed:
			print("connection closed in starting frame")
			print("re-establishing connection...")
			self.websocket = None
			await self.on_network_status_change()

	async def send_frame(self, array):
		while self.websocket is None:
			print("none")
			time.sleep(1)
			continue
		try:
			# the converted bytearray is sent using websockets
			await self.websocket.send(array)
		except websockets.exceptions.ConnectionClosed:
			print("connection closed in sending frame")
			print("re-establishing connection...")
			self.websocket = None
			await self.on_network_status_change()

	def connect(self, loop):
		asyncio.set_event_loop(loop)
		loop.run_until_complete(self._connect())

	async def receive_message(self):
		while self.websocket is None:
			print("none")
			time.sleep(1)
			continue
		while True:
			try:
				# when a message is received, its converted to dictionary and sent for processing
				message = await self.websocket.recv()
				self.on_receive(json.loads(message))
			except websockets.exceptions.ConnectionClosed:
				print("connection closed in recieve msg")
				print("re-establishing connection...")
				self.websocket = None
				await self.on_network_status_change()
			except socket.gaierror:
				await self.on_network_status_change()

	async def _connect(self):
		if self.websocket is None:
			try:
				self.websocket = await websockets.client.connect(self.url, ssl=True)
				if self.websocket.open:
					print("Connection established correctly. Client Connected!")
				await asyncio.sleep(1)
			except socket.gaierror:
				time.sleep(1)
				await self.on_network_status_change()
		else:
			print("Already Connected!")

	async def re_connect(self):
		# if internet is down we try and reconnect
		self.websocket = None
		print("Internet not found while reconnecting..")
		await self._connect()
