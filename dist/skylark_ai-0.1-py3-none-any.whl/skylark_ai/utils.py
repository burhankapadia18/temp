from skylark_ai.constants import WEBSOCKET_AUTH_API
import requests
import socket


def get_websocket_auth_token(token):
    try:
        response = requests.post(WEBSOCKET_AUTH_API, headers={'Authorization': 'token ' + token})
        if response.status_code == 201:
            return response.json().get('key')
        else:
            return None
    except socket.gaierror:
        print("Internet not found")


def get_bytes_from_file(filename):
    return open(filename, "rb").read()
